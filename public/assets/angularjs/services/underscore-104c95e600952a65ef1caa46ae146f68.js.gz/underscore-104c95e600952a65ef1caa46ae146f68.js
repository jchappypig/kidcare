App.factory('_', ['$window', function($window) {
  'use strict';

  return $window._;
}]);
