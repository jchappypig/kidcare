window.App = angular.module('KidcareApp', ['ngResource']);
